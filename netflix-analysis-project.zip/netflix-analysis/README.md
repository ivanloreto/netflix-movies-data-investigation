# 🎬 Netflix Movies Data Analysis Project

This project is part of my Data Science portfolio and was developed using content from DataCamp. The goal was to explore and analyze a dataset of Netflix movies using Python.

## 📌 Project Overview

- Investigates patterns and trends in Netflix’s top movies.
- Performs exploratory data analysis (EDA) on movie duration, release year, and popularity.
- Uses Python with libraries such as pandas, seaborn, and matplotlib.

## 📁 Files

- `Netflix_Project.html`: Exported DataCamp project containing all code and visualizations.
- `README.md`: Project description.

## 🚀 Tools Used

- Python (pandas, seaborn, matplotlib)
- DataCamp’s interactive platform

## 🔗 Author

**Iván Loreto**  
[LinkedIn](https://www.linkedin.com/in/iván-loreto-9279b269)
